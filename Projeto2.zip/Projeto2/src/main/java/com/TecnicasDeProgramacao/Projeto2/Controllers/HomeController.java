package com.TecnicasDeProgramacao.Projeto2.Controllers;

public class HomeController {

}
