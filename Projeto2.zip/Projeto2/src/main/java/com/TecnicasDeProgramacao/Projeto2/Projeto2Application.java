package com.TecnicasDeProgramacao.Projeto2;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import javafx.application.Application;

@SpringBootApplication
public class Projeto2Application {

	public static void main(String[] args) {
		Application.launch(JavaFxApplication.class, args);
	}

}
